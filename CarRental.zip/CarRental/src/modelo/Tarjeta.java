/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author israelchuchuca
 */
class Tarjeta {
    
    private int tar_id;
    private String tar_tipo_de_tarjeta;
    private String tar_numero_Tarjeta;
    private String tar_nombre; 
    private String tar_cbb;
    
}
