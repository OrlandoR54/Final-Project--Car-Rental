/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author israelchuchuca
 */
public class FacturaDetalle {
    
    private int fac_det_id;
    private int fac_det_cantidad;
    private double fac_det_precio_unitario;
    private double fac_det_subtotal;
    private double fac_det_total;
    private Vehiculo vehiculo;
    
}
