/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author israelchuchuca
 */
class Devolucion {
    
    private int dev_id;
    private double dev_kilometro_extra;
    private boolean dev_tanque_gasolina;
    private double dev_costo_daños;
    private double dev_garantia_devuelta;
}
