/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author israelchuchuca
 */
public class Usuario {
    
    private int us_id;
    private String us_nombre;
    private String us_apellido;
    private String us_direccion;
    private String us_email;
    private String us_password;
    private Catalogo_Vehiculo us_catalogo;
    //private Kardex us_kardex;
}
